/*
  -------------------------------------------------------------------
  
  Copyright (C) 2012, Andrew W. Steiner
  
  This file is part of Bamr.
  
  Bamr is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 3 of the License, or
  (at your option) any later version.
  
  Bamr is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with Bamr. If not, see <http://www.gnu.org/licenses/>.

  -------------------------------------------------------------------
*/
#ifndef BAMR_H
#define BAMR_H

#include <iostream>

#include <mpi.h>

#include <o2scl/cold_nstar.h>
#include <o2scl/tensor.h>
#include <o2scl/schematic_eos.h>
#include <o2scl/apr_eos.h>
#include <o2scl/skyrme_eos.h>
#include <o2scl/rmf_eos.h>
#include <o2scl/gsl_rnga.h>
#include <o2scl/gsl_mmin_simp.h>
#include <o2scl/hist.h>
#include <o2scl/hist_2d.h>
#include <o2scl/shared_ptr.h>
#include <o2scl/expect_val.h>
#include <o2scl/uniform_grid.h>
#include <o2scl/table3d.h>
#include <o2scl/hdf_file.h>
#include <o2scl/hdf_io.h>

#ifdef BAMR_READLINE
#include <o2scl/cli_readline.h>
#else
#include <o2scl/cli.h>
#endif

#include "misc.h"
#include "entry.h"
#include "models.h"

#ifndef DOXYGEN
namespace o2scl {
#endif

  /** \brief Statistical analysis of EOS from M and R constraints

      \todo It's not clear if successive calls of the mcmc command
      really work. For now, one may have ensure the program exits
      after each mcmc() run. 
   */
  class bamr {
    
  protected:

    /// If true, then parameter names have been written to the HDF file
    bool first_file_update;

    /// \name Expectation values
    //@{
    /** \brief Pressure versus energy density
     */
    hist_set_ev_x peden;
    /** \brief A posteriori M and R constraints
	
	Only output if there is at least 1 source data file
     */
    std::vector<hist_ev_2d> postmr;
    /** \brief Mass versus radius curve
     */
    hist_set_ev_y massrad;
    /** \brief Pressure versus baryon density

	Only if \ref baryon_density is true.
     */
    hist_set_ev_x presnb;
    /** \brief Pressure versus baryon density

	Only if \ref baryon_density is true.
     */
    hist_set_ev_x eoanb;
    /** \brief symmetry energy histogram

	Only if the specified model gives true for \ref has_esym .
     */
    hist_ev_2d esyml;
    /** \brief Ratio of EOS to calibrated EOS
     */
    hist_set_ev_x ratio;
    /** \brief Output values of the parameters
     */
    std::vector<hist_ev_1d> param;
    /** \brief Central energy densities
     */
    std::vector<hist_ev_1d> cenergy_ev;
    /** \brief Central baryon densities
     */
    std::vector<hist_ev_1d> cbaryon_ev;
    /** \brief L

	Only if the specified model gives true for \ref has_esym .
     */
    hist_ev_1d L_ev;
    /** \brief S

	Only if the specified model gives true for \ref has_esym .
     */
    hist_ev_1d S_ev;
    /** \brief Maximum mass
     */
    hist_ev_1d mmax_ev;
    //@}
    
    /// Number of bins for all histograms (default 100)
    size_t hist_size;

    /// Comparison EOS
    table_units base_eos;
    
    /** \name Histogram limits
    */
    //@{
    double nb_low;
    double nb_high;
    double e_low;
    double e_high;
    double eoa_low;
    double eoa_high;
    double p_low;
    double p_high;
    double r_low;
    double r_high;
    double m_low;
    double m_high;
    double c_low;
    double c_high;
    double L_low;
    double L_high;
    double S_low;
    double S_high;
    //@}

    /// \name Grids
    //@{
    uniform_grid<double> nb_grid;
    uniform_grid<double> e_grid;
    uniform_grid<double> eoa_grid;
    uniform_grid<double> p_grid;
    uniform_grid<double> r_grid;
    uniform_grid<double> m_grid;
    uniform_grid<double> c_grid;
    uniform_grid<double> L_grid;
    uniform_grid<double> S_grid;
    //@}

    /// Store the full Markov chain
    ovector markov_chain;

    /// Number of chains
    size_t chain_size;
  
    /// Update expectation values from histogram data
    void update_evs();

    /// Initialize 
    virtual int init(entry &low, entry &high);

    /// Add a measurement
    virtual int add_measurement
      (entry &e, o2_shared_ptr<table_units>::type tab_eos,
       o2_shared_ptr<table_units>::type tab_mvsr,
       double weight);
    
    /// Write histogram data to files with prefix \c fname
    virtual int update_files(std::string fname, 
			     model &modp, entry &e_current);
    //@}

    /// \name Parameters accessed by 'set' and 'get' command-line arguments
    //@{
    /** \brief If true, output debug information about the input data 
	files (default false)
    */
    bool debug_load;

    /// If true, store the full Markov chain (default false)
    bool store_chain;
    
    /// Maximum number of iterations (default 0)
    int max_iters;

    /// If true, use the default crust (default true)
    bool use_crust;

    /// If true, output stellar properties for debugging
    bool debug_star;
    
    /// If true, output equation of state for debugging 
    bool debug_eos;

    /// If true, output next point
    bool output_next;

    /// If true, compute the baryon density
    bool baryon_density;

    /// MCMC stepsize factor (default 15)
    double step_fac;

    /// The lower threshold for the input distributions
    double input_dist_thresh;

    /// An upper mass threshold
    double exit_mass;

    /// Maximum mass allowed for any of the individual neutron stars
    double max_mass;
  
    /// Minimum allowed maximum mass
    double min_max_mass;

    /// Number of warm up iterations
    int n_warm_up;

    /// Input file (default "bay.in")
    std::string in_file;

    /** \brief Time in seconds (3600 seconds is one hour, default is
	86400 seconds or 1 day)
    */
    double max_time;

    /// If non-zero, use as the seed for the random number generator
    int user_seed;

    /** \brief If true, output more detailed information about the 
	best point
    */
    bool best_detail;
    //@}

    /// \name MPI properties
    //@{
    /// The MPI processor rank
    int mpi_rank;

    /// The MPI number of processors
    int mpi_nprocs;

    /// The MPI starting time
    double mpi_start_time;
    //@}
    
    /// \name Input data
    //@{
    /// Input probability distributions
    std::vector<table3d> tlist;

    /// The names for each source
    std::vector<std::string> source_names;

    /// File names for each source
    std::vector<std::string> fnames;

    /// Slice names for each source
    std::vector<std::string> slice_names;

    /// Filename for EOS to calibrate by
    std::string calibrate_fname;

    /// The number of sources
    size_t nsources;
    //@}

    /// \name Parameter limits
    //@{
    entry low, high;
    //@}

    /** \name Mass and radius limits for any individual neutron star
	
	By default, radii are limited to between 5 and 18 km, and
	masses are limited to between 0.8 and 3.0 solar masses.
    */
    //@{
    double m_min, m_max, r_min, r_max;
    //@}

    /// \name Other variables
    //@{
    /// To evalute temperature
    FunctionParser fp;

    /// A string indicating which model is used, set in \ref set_model().
    std::string model_type;
    
    /// True if the model provides S and L
    bool has_esym;

    /// Number of parameters, set in \ref set_model()
    size_t nparams;
    
    /// Schwarzchild radius (set in constructor)
    double schwarz_km;

    /// The model for the EOS
    model *modp;

    /// The second copy of the model for the EOS
    model *modp2;

    /// Random number generator
    gsl_rnga gr;
  
    /// The screen output file
    std::ofstream scr_out;
    //@}

    /// \name Internal functions 
    //@{
    /// The old hist_get() function for the table3d format
    double hist_get(table3d &t, double ix, double iy, std::string scol);

    /// Load input probability distributions (called by mcmc())
    virtual int load_mc();
  
    /** \brief Compute P(M|D) from parameters in entry \c e
	
	Called by mcmc().
    */
    virtual double compute_weight(entry &e, model &modref, 
				  tov_solve &ts, bool &success,
				  uvector &wgts, bool warm_up);
    
    /** \brief Tabulate EOS and then use in cold_nstar

	Called by compute_weight().
    */
    virtual int compute_star(entry &e, model &modref, tov_solve &ts, 
			     bool &success);

    /** \brief Read input file with name given in \ref in_file

	Called by mcmc().
     */
    virtual int read_input(entry &e_current);

    /// Output the "best" EOS obtained so far (called by mcmc())
    virtual int output_best
      (std::string fname, entry &e_best, double w_best,
       o2_shared_ptr<table_units>::type tab_eos,
       o2_shared_ptr<table_units>::type tab_mvsr,
       uvector &wgts);
    //@}

    /** \brief Set the model for the EOS to use
     */
    virtual int set_model(std::vector<std::string> &sv, bool itive_com);

    /** \brief Run with filename prefix \c fname

	In order to save the code from copying results over if a step
	is rejected, the Metropolis steps alternate between two kinds.
	In the first kind of step, \ref modp is the previous point and
	\ref modp2 is the new point to be considered, and in the
	second kind of step, \ref modp2 is the old point and \ref modp
	is the new point to be considered. This two-step procedure is
	also why there are two TOV solvers, i.e. \ref ts and \ref ts2.
     */
    virtual int mcmc(std::vector<std::string> &sv, bool itive_com);

    /// \name TOV solver objects
    //@{
    /// EOS interpolation object for TOV solver
    tov_interp_eos teos;

    /// Pointer to a TOV solver
    tov_solve *ts;
  
    /// Second pointer to a TOV solver
    tov_solve *ts2;

    /// Default TOV solver
    tov_solve def_ts;
  
    /// Second default TOV solver
    tov_solve def_ts2;
    //@}

  public:

    bamr();

    virtual ~bamr();

    /// Main wrapper for parsing command-line arguments
    virtual int run(int argc, char *argv[]);

  };

#ifndef DOXYGEN
}
#endif

#endif
