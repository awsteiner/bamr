/*
  -------------------------------------------------------------------
  
  Copyright (C) 2012, Andrew W. Steiner
  
  This file is part of Bamr.
  
  Bamr is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 3 of the License, or
  (at your option) any later version.
  
  Bamr is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with Bamr. If not, see <http://www.gnu.org/licenses/>.

  -------------------------------------------------------------------
*/
#include "bamr.h"

#include <o2scl/vector.h>

using namespace std;
using namespace o2scl;
// For I/O with HDF files
using namespace o2scl_hdf;
// For pi, pi^2, etc.
using namespace o2scl_const;
  
bamr::bamr() {

  // From running_stats
  nsources=0;
  first_file_update=false;
  hist_size=100;

  debug_load=false;
  store_chain=false;

  // Default parameter values

  step_fac=15.0;
  schwarz_km=o2scl_mks::schwarzchild_radius/1.0e3;
  // Default to 24 hours
  max_time=3.6e3*24;
  n_warm_up=500;
  in_file="default.in";
  // Minimum allowed maximum mass
  min_max_mass=1.93;
  // Maximum mass allowed for any of the individual neutron stars
  max_mass=3.0;

  nparams=0;
  model_type="";
  debug_star=false;
  debug_eos=false;
  output_next=true;
  baryon_density=true;
  exit_mass=10.0;
  input_dist_thresh=0.0;
  use_crust=true;
  user_seed=0;
  best_detail=false;
  max_iters=0;
  chain_size=0;

  // Anything lower than 0.5 is not given in the Rinf data
  m_min=0.8;
  m_max=3.0;
  r_min=5.0;
  // We need at least 18 km to fit the x7 contours
  r_max=18.0;

  // -----------------------------------------------------------
  // Grid limits
  
  nb_low=0.04;
  nb_high=1.04;
  
  e_low=0.3;
  e_high=10.0;

  p_low=1.0e-4;
  p_high=15.0;

  eoa_low=0.0;
  eoa_high=2.5;

  L_low=0.0/hc_mev_fm;
  L_high=120.0/hc_mev_fm;

  S_low=28.0/hc_mev_fm;
  S_high=38.0/hc_mev_fm;

  // Change the mass minimum to 0.2 so that we get a full mass vs.
  // radius curve, even though the data doesn't go that far down
  r_low=r_min;
  r_high=r_max;
  m_low=0.2;
  m_high=m_max;
  
  // Limits for ratio
  c_low=0.1;
  c_high=10.0;
  
  modp=0;
  modp2=0;

  // -----------------------------------------------------------
  // Set up TOV solvers

  teos.verbose=0;
  teos.set_units("1/fm^4","1/fm^4","1/fm^3");

  def_ts.verbose=0;
  def_ts.set_units("1/fm^4","1/fm^4","1/fm^3");
  def_ts.set_eos(teos);
  ts=&def_ts;

  def_ts2.verbose=0;
  def_ts2.set_units("1/fm^4","1/fm^4","1/fm^3");
  def_ts2.set_eos(teos);
  ts2=&def_ts2;
}

bamr::~bamr() {
  if (modp!=0) delete modp;
  if (modp2!=0) delete modp2;
}

int bamr::init(entry &low, entry &high) {
  
  scr_out << "In init()." << std::endl;

  if (low.np==0 || high.np==0) {
    O2SCL_ERR("No parameters in bamr::init().",gsl_einval);
  }

  // -----------------------------------------------------------
  // Make grids

  nb_grid=uniform_grid_end<double>(nb_low,nb_high,hist_size);
  e_grid=uniform_grid_end<double>(e_low,e_high,hist_size);
  eoa_grid=uniform_grid_end<double>(eoa_low,eoa_high,hist_size);
  p_grid=uniform_grid_log_end<double>(p_low,p_high,hist_size);
  r_grid=uniform_grid_end<double>(r_low,r_high,hist_size);
  m_grid=uniform_grid_end<double>(m_low,m_high,hist_size);
  c_grid=uniform_grid_log_end<double>(c_low,c_high,hist_size);
  L_grid=uniform_grid_end<double>(L_low,L_high,hist_size);
  S_grid=uniform_grid_end<double>(S_low,S_high,hist_size);
  
  // -----------------------------------------------------------
  // Read EOS to calibrate by

  scr_out << "Reading base EOS in file: " << calibrate_fname.c_str() << endl;
  ifstream fin(calibrate_fname.c_str());
  base_eos.line_of_names("ed pr");
  base_eos.set_unit("ed","1/fm^4");
  base_eos.set_unit("pr","1/fm^4");
  for(size_t i=0;i<217;i++) {
    double tmp[2];
    fin >> tmp[0] >> tmp[1];
    base_eos.line_of_data(2,tmp);
    if (i%3==0) {
      scr_out.width(3);
      scr_out << i << " " << tmp[0] << " " << tmp[1] << endl;
    }
  }
  fin.close();
  scr_out << endl;

  // -----------------------------------------------------------
  // Init histograms and expect_val objects

  // Initialize the hist_2d for each object
  if (nsources>0) {
    postmr.resize(nsources);
    for(size_t i=0;i<nsources;i++) {
      postmr[i].count=0;
      postmr[i].h.set_bin_edges(r_grid,m_grid);
      postmr[i].ev.set_blocks(hist_size,hist_size,20,1);
    }
  }

  // Initialize the hist for each EOS parameter and each source
  param.resize(nsources+nparams);
  for(size_t i=0;i<nparams;i++) {
    uniform_grid_end<double> ug(low.params[i],high.params[i],hist_size);
    param[i].h.set_bin_edges(ug);
    param[i].ev.set_blocks(hist_size,20,1);
    param[i].count=0;
  }
  for(size_t i=0;i<nsources;i++) {
    uniform_grid_end<double> ug(m_low,m_high,hist_size);
    param[i+nparams].h.set_bin_edges(ug);
    param[i+nparams].ev.set_blocks(hist_size,20,1);
    param[i+nparams].count=0;
  }

  // Initialize the hist central energy and baryon density
  cenergy_ev.resize(nsources+1);
  for(size_t i=0;i<nsources+1;i++) {
    cenergy_ev[i].h.set_bin_edges(e_grid);
    cenergy_ev[i].ev.set_blocks(hist_size,20,1);
    cenergy_ev[i].count=0;
  }
  cbaryon_ev.resize(nsources+1);
  for(size_t i=0;i<nsources+1;i++) {
    cbaryon_ev[i].h.set_bin_edges(nb_grid);
    cbaryon_ev[i].ev.set_blocks(hist_size,20,1);
    cbaryon_ev[i].count=0;
  }

  // Initialize hist for maximum mass
  mmax_ev.h.set_bin_edges(m_grid);
  mmax_ev.ev.set_blocks(hist_size,20,1);
  mmax_ev.count=0;
  
  // Initialize the remaining hist_2d objects

  peden.h.set_bin_edges(e_grid,p_grid);
  peden.ev.set_blocks(hist_size,hist_size,20,1);
  peden.count.allocate(hist_size);
  peden.count.set_all(0);

  if (has_esym) {
    // Initialize hist for S vs. L
    esyml.h.set_bin_edges(S_grid,L_grid);
    esyml.ev.set_blocks(hist_size,hist_size,20,1);
    esyml.count=0;

    // Initialize hist for L
    L_ev.h.set_bin_edges(L_grid);
    L_ev.ev.set_blocks(hist_size,20,1);
    L_ev.count=0;

    // Initialize hist for S
    S_ev.h.set_bin_edges(S_grid);
    S_ev.ev.set_blocks(hist_size,20,1);
    S_ev.count=0;
  }

  eoanb.h.set_bin_edges(nb_grid,eoa_grid);
  eoanb.ev.set_blocks(hist_size,hist_size,20,1);
  eoanb.count.allocate(hist_size);
  eoanb.count.set_all(0);

  presnb.h.set_bin_edges(nb_grid,p_grid);
  presnb.ev.set_blocks(hist_size,hist_size,20,1);
  presnb.count.allocate(hist_size);
  presnb.count.set_all(0);

  massrad.h.set_bin_edges(r_grid,m_grid);
  massrad.ev.set_blocks(hist_size,hist_size,20,1);
  massrad.count.allocate(hist_size);
  massrad.count.set_all(0);

  ratio.h.set_bin_edges(e_grid,c_grid);
  ratio.ev.set_blocks(hist_size,hist_size,20,1);
  ratio.count.allocate(hist_size);
  ratio.count.set_all(0);

  return 0;
}

int bamr::add_measurement
(entry &e, o2scl::o2_shared_ptr<o2scl::table_units>::type tab_eos,
 o2scl::o2_shared_ptr<o2scl::table_units>::type tab_mvsr,
 double weight) {

  if (store_chain) {
    chain_size=e.np+nsources+1;
    ovector tmp;
    for(size_t i=0;i<e.np;i++) {
      markov_chain.push_back(e.params[i]);
    }
    for(size_t i=0;i<nsources;i++) {
      markov_chain.push_back(e.mass[i]);
    }
    markov_chain.push_back(weight);
  }

  double mmax=tab_mvsr->max("gm");
  double rmax=tab_mvsr->max("r");
  double pmax=tab_eos->max("pr");
  double emax=tab_eos->max("ed");
  double nbmax=0.0;
  if (baryon_density) nbmax=tab_eos->max("nb");

  double val=1.0;
    
  // Update parameter histograms
  for(size_t i=0;i<e.np;i++) {
    param[i].h.update(e.params[i],val);
    param[i].count++;
  }

  // Update 1D mass, and posterior M,R histograms for each source
  for(size_t i=0;i<nsources;i++) {
    param[e.np+i].h.update(e.mass[i],val);
    param[e.np+i].count++;
    postmr[i].h.update(e.rad[i],e.mass[i],val);
    postmr[i].count++;
  }

  // Update symmetry energy histogram
  double L=tab_eos->get_constant("L");
  double S=tab_eos->get_constant("S");
  if (has_esym) {
    if (S>S_low && S<S_high) {
      S_ev.h.update(S,val);
      S_ev.count++;
    }
    if (L>L_low && L<L_high) {
      L_ev.h.update(L,val);
      L_ev.count++;
      if (S>S_low && S<S_high) {
	esyml.h.update(S,L,val);
	esyml.count++;
      }
    }
  }

  // Update 2D histograms

  for(size_t i=0;i<hist_size;i++) {

    double eval=peden.h.get_x_rep_i(i);
    double mval=massrad.h.get_y_rep_i(i);
    double pval=tab_eos->interp("ed",eval,"pr");
    double rval=tab_mvsr->interp("gm",mval,"r");
    double cval=pval/base_eos.interp("ed",eval,"pr");

    if (eval<e_high && eval>e_low && pval>p_low && pval<p_high && 
	pval<pmax && eval<emax) {
      peden.h.update(eval,pval,val);
      peden.count[i]++;
    }
    
    if (baryon_density) {
      
      double nbval=presnb.h.get_x_rep_i(i), pval2, eval2;
      
      pval2=tab_eos->interp("nb",nbval,"pr");
      eval2=tab_eos->interp("nb",nbval,"ed");
      
      double eoa_val2=eval2/nbval-939.0/o2scl_const::hc_mev_fm;
      
      if (nbval<nb_high && nbval>nb_low && pval2>p_low && pval2<p_high && 
	  pval2<pmax && nbval<nbmax) {
	presnb.h.update(nbval,pval2,val);
	presnb.count[i]++;
      }
      
      if (nbval<nb_high && nbval>nb_low && eoa_val2>eoa_low && 
	  eoa_val2<eoa_high && eval2<emax && nbval<nbmax) {
	eoanb.h.update(nbval,eoa_val2,val);
	eoanb.count[i]++;
      }

      // End of loop 'if (baryon_density)'
    }
	
    if (rval<r_high && rval>r_low && mval>m_low && mval<m_high &&
	rval<rmax && mval<mmax) {
      
      massrad.h.update(rval,mval,val);
      massrad.count[i]++;
    }

    if (eval<e_high && eval>e_low && cval>c_low && cval<c_high) {
      ratio.h.update(eval,cval,val);
      ratio.count[i]++;
    }

    // End of loop 'for(size_t i=0;i<hist_size;i++)' for 2d histograms
  }

  // Update central energy and baryon density of maximum mass star
  double cenergy=tab_mvsr->get("ed",tab_mvsr->lookup("gm",mmax));
  if (cenergy>e_low && cenergy<e_high) {
    cenergy_ev[0].h.update(cenergy,val);
    cenergy_ev[0].count++;
  }
  if (baryon_density) {
    double cbaryon=tab_mvsr->get("nb",tab_mvsr->lookup("gm",mmax));
    if (cbaryon>nb_low && cbaryon<nb_high) {
      cbaryon_ev[0].h.update(cbaryon,val);
      cbaryon_ev[0].count++;
    }
  }

  // Update with maximum mass
  if (mmax<m_high && mmax>m_low) {
    mmax_ev.h.update(mmax,val);
    mmax_ev.count++;
  }

  // Update central energy and baryon density of each individual star
  for(size_t i=1;i<=nsources;i++) {
    cenergy=tab_mvsr->interp("gm",e.mass[i-1],"ed");
    if (cenergy>e_low && cenergy<e_high) {
      cenergy_ev[i].h.update(cenergy,val);
      cenergy_ev[i].count++;
    }
    if (baryon_density) {
      double cbaryon=tab_mvsr->interp("gm",e.mass[i-1],"nb");
      if (cbaryon>nb_low && cbaryon<nb_high) {
	cbaryon_ev[i].h.update(cbaryon,val);
	cbaryon_ev[i].count++;
      }
    }
  }

  return 0;
}

void bamr::update_evs() {
  
  for(size_t k=0;k<nsources+nparams;k++) {
    param[k].update();
  }

  for(size_t k=0;k<nsources;k++) {
    postmr[k].update();
  }

  peden.update();
  massrad.update();
  ratio.update();
  mmax_ev.update();
  if (has_esym) {
    esyml.update();
    L_ev.update();
    S_ev.update();
  }

  for(size_t k=0;k<nsources+1;k++) {
    cenergy_ev[k].update();
  }

  if (baryon_density) {
    presnb.update();
    eoanb.update();
    for(size_t k=0;k<nsources+1;k++) {
      cbaryon_ev[k].update();
    }
  }

  return;
}

int bamr::update_files(string fname, model &modp, entry &e_current) {

  hdf_file hf;

  // File for parameter histograms
  hf.open(fname+"_out");
    
  // First time, output parameter names. We can't compare with
  // zero, because that may never happen.
  if (first_file_update==false) {
    vector<string> param_names2;
    for(size_t i=0;i<e_current.np;i++) {
      param_names2.push_back(modp.param_name(i));
    }
    hf.sets_vec("param_names",param_names2);
    first_file_update=true;

    hf.set_szt("hist_size",hist_size);
  }

  // Output the parameter histograms
  for(size_t i=0;i<e_current.np;i++) {
    hdf_output(hf,param[i].h,((string)"param_")+modp.param_name(i)+".h");
    hdf_output(hf,param[i].ev,((string)"param_")+modp.param_name(i)+".ev");
    hf.set_szt(((string)"param_")+modp.param_name(i)+".count",param[i].count);
  }

  // Output the individual mass histograms
  for(size_t i=0;i<nsources;i++) {
    hdf_output(hf,param[i+e_current.np].h,source_names[i]+"_mass.h");
    hdf_output(hf,param[i+e_current.np].ev,source_names[i]+"_mass.ev");
    hf.set_szt(source_names[i]+"_mass.count",param[i+e_current.np].count);
  }

  // M vs. R curve
  hdf_output(hf,massrad.h,"massrad.h");
  hdf_output(hf,massrad.ev,"massrad.ev");
  hf.set_szt_vec("massrad.count",massrad.count);

  // pressure vs. energy density curve
  hdf_output(hf,peden.h,"peden.h");
  hdf_output(hf,peden.ev,"peden.ev");
  hf.set_szt_vec("peden.count",peden.count);

  if (has_esym) {
    // S-L plot
    hdf_output(hf,esyml.h,"esyml.h");
    hdf_output(hf,esyml.ev,"esyml.ev");
    hf.set_szt("esyml.count",esyml.count);

    // L
    hdf_output(hf,L_ev.h,"L.h");
    hdf_output(hf,L_ev.ev,"L.ev");
    hf.set_szt("L.count",L_ev.count);

    // S
    hdf_output(hf,S_ev.h,"S.h");
    hdf_output(hf,S_ev.ev,"S.ev");
    hf.set_szt("S.count",S_ev.count);
  }

  if (baryon_density) {
    // pressure vs. baryon density curve
    hdf_output(hf,presnb.h,"presnb.h");
    hdf_output(hf,presnb.ev,"presnb.ev");
    hf.set_szt_vec("presnb.count",presnb.count);

    // energy per baryon vs. baryon density curve
    hdf_output(hf,eoanb.h,"eoanb.h");
    hdf_output(hf,eoanb.ev,"eoanb.ev");
    hf.set_szt_vec("eoanb.count",eoanb.count);
  }

  // relative pressure vs. energy density curve
  hdf_output(hf,ratio.h,"ratio.h");
  hdf_output(hf,ratio.ev,"ratio.ev");
  hf.set_szt_vec("ratio.count",ratio.count);

  if (nsources>0) {
    // posterior estimations of M and R
    for(size_t ik=0;ik<nsources;ik++) {
      hdf_output(hf,postmr[ik].h,source_names[ik]+"_postmr.h");
      hdf_output(hf,postmr[ik].ev,source_names[ik]+"_postmr.ev");
      hf.set_szt(source_names[ik]+"_postmr.count",postmr[ik].count);
    }
  }
	  
  // File for central energy density histograms
  string tab_name;
  for(size_t ik=0;ik<=nsources;ik++) {
    if (ik==0) {
      tab_name="cenergy";
    } else {
      tab_name=source_names[ik-1]+"_cenergy";
    }
    hdf_output(hf,cenergy_ev[ik].h,tab_name+".h");
    hdf_output(hf,cenergy_ev[ik].ev,tab_name+".ev");
    hf.set_szt(tab_name+".count",cenergy_ev[ik].count);
    if (baryon_density) {
      if (ik==0) {
	tab_name="cbaryon";
      } else {
	tab_name=source_names[ik-1]+"_cbaryon";
      }
      hdf_output(hf,cbaryon_ev[ik].h,tab_name+".h");
      hdf_output(hf,cbaryon_ev[ik].ev,tab_name+".ev");
      hf.set_szt(tab_name+".count",cbaryon_ev[ik].count);
    }
  }

  // maximum mass
  hdf_output(hf,mmax_ev.h,"mmax.h");
  hdf_output(hf,mmax_ev.ev,"mmax.ev");
  hf.set_szt("mmax.count",mmax_ev.count);

  // Store full Markov chain
  if (store_chain) {
    hf.setd_vec("markov_chain",markov_chain);
    hf.set_szt("chain_size",chain_size);
  }

  hf.close();

  return 0;
}

int bamr::load_mc() {

  double tot, max;

  string name;
    
  if (nsources>0) {

    tlist.resize(nsources);
    
    scr_out << "\nInput data files: " << endl;
    
    for(size_t k=0;k<nsources;k++) {

      hdf_file hf;
      hf.open(fnames[k]);
      hdf_input(hf,tlist[k]);
      hf.close();

      // Renormalize
      tot=0.0;
      max=0.0;
      for(size_t i=0;i<tlist[k].get_nx();i++) {
	for(size_t j=0;j<tlist[k].get_ny();j++) {
	  tot+=tlist[k].get(i,j,slice_names[k]);
	  if (tlist[k].get(i,j,slice_names[k])>max) {
	    max=tlist[k].get(i,j,slice_names[k]);
	  }
	}
      }
      for(size_t i=0;i<tlist[k].get_nx();i++) {
	for(size_t j=0;j<tlist[k].get_ny();j++) {
	  tlist[k].set(i,j,slice_names[k],
		       tlist[k].get(i,j,slice_names[k])/max);
	  //} else {
	  //tlist[k].set(i,j,slice_names[k],
	  //tlist[k].get(i,j,slice_names[k])/tot);
	  //}
	}
      }

      if (debug_load) {
	cout << fnames[k] << endl;
	for(size_t i=0;i<tlist[k].get_nx();i++) {
	  cout << i << " " << tlist[k].get_grid_x(i) << endl;
	}
	for(size_t j=0;j<tlist[k].get_ny();j++) {
	  cout << j << " " << tlist[k].get_grid_y(j) << endl;
	}
	for(size_t i=0;i<tlist[k].get_nx();i++) {
	  for(size_t j=0;j<tlist[k].get_ny();j++) {
	    cout << tlist[k].get(i,j,slice_names[k]) << " ";
	  }
	  cout << endl;
	}
      }

      scr_out.setf(ios::left);
      scr_out.width(25);
      scr_out << fnames[k] << " ";
      scr_out.width(6);
      scr_out << source_names[k] << " " << tot << " " << max << " ";
      scr_out.unsetf(ios::left);
      scr_out << hist_get(tlist[k],10.0,1.4,slice_names[k]) << endl;
    }

    scr_out << endl;
  }
    
  return 0;
}
  
int bamr::compute_star(entry &e, model &modref, tov_solve &tsr, 
			bool &success) {
  
  success=true;

  bool test_eos_fail;
  modref.compute_eos(e,test_eos_fail,scr_out);
  o2_shared_ptr<table_units>::type tab_eos=modref.cns.get_eos_results();
  tab_eos->set_interp_type(itp_linear);

  if (debug_eos) {
    hdf_file hfde;
    hfde.open("debug_eos.o2");
    hdf_output(hfde,*tab_eos,"eos");
    hfde.close();
    if (!debug_star) {
      scr_out << "Automatically exiting since 'debug_eos' is true." << endl;
      exit(-1);
    }
  }

  if (test_eos_fail==true) {
    success=false;
    return 0;
  }

  // If requested, compute the baryon density automatically
  if (baryon_density) {

    // Obtain the baryon density calibration point from the model

    double n1, e1;
    modref.baryon_density_point(n1,e1);
    
    if (n1<=0.0 && e1<=0.0) {
      O2SCL_ERR2("Computing the baryon density requires one ",
		 "calibration point in bamr::compute_star().",gsl_einval);
    }

    // Compute inverse of gibbs energy density, 'igb'
    tab_eos->new_column("igb");
    for(size_t i=0;i<tab_eos->get_nlines();i++) {
      tab_eos->set("igb",i,1.0/(tab_eos->get("ed",i)+tab_eos->get("pr",i)));
    }

    // Compute integral of 'igb' relative to ed='e1', called 'iigb'
    tab_eos->new_column("iigb");
    for(size_t i=0;i<tab_eos->get_nlines();i++) {
      if (e1<=tab_eos->get("ed",i)) {
	tab_eos->set("iigb",i,
		     tab_eos->integ("ed",e1,tab_eos->get("ed",i),"igb"));
      } else {
	tab_eos->set("iigb",i,
		     -tab_eos->integ("ed",tab_eos->get("ed",i),e1,"igb"));
      }
    }

    // Compute normalization constant
    double Anb=n1/exp(tab_eos->interp("ed",e1,"iigb"));
    if (!finite(Anb) || Anb<0.0) {
      scr_out << "Baryon density normalization problem." << endl;
      success=false;
      return 0;
    }

    // Now compute baryon density

    tab_eos->new_column("nb");

    for(size_t i=0;i<tab_eos->get_nlines();i++) {      

      // If the density is too low, then just use zero baryon density.
      // This pressure (10^{-5} fm^{-4}) corresponds to a baryon 
      // density of about 3e-3 fm^{-3}.

      if (use_crust==false && tab_eos->get("pr",i)<1.0e-5) {

	tab_eos->set("nb",i,0.0);

      } else {
	
	double nbt=Anb*exp(tab_eos->get("iigb",i));
	if (!finite(nbt)) {
	  scr_out << "Baryon density normalization problem." << endl;
	  success=false;
	  return 0;
	  /*
	    cout << "Baryon density not finite." << endl;
	    cout << "i,ed,pr,igb,iigb: " << i << " " << Anb << " "
	    << tab_eos->get("ed",i) << " "
	    << tab_eos->get("pr",i) << " " << tab_eos->get("igb",i) << " "
	    << tab_eos->get("iigb",i) << endl;
	    exit(-1);
	  */
	} 
	tab_eos->set("nb",i,nbt);
      }
    }

  }

  // Read the EOS into the tov_eos object. We don't specify a baryon
  // number density column here, even though it might be provided,
  // just to make the TOV solver a bit faster.
  teos.read_table(*tab_eos,"ed","pr");

  // Solve for M vs. R curve
  tsr.mvsr();
  o2_shared_ptr<table_units>::type tab_mvsr=tsr.get_results();
  tab_mvsr->set_interp_type(itp_linear);
  
  // If the EOS is sufficiently stiff, the TOV solver will output
  // gibberish, i.e. masses and radii equal to zero, especially at the
  // higher pressures. This rules these EOSs out, as they would likely
  // be acausal anyway. If this happens frequently, it might signal
  // a problem. 
  size_t ir=tab_mvsr->get_nlines()-1;
  if ((*tab_mvsr)["gm"][ir]<1.0e-10 ||
      (*tab_mvsr)["gm"][ir-1]<1.0e-10) {
    scr_out << "TOV failure fix." << endl;
    success=false;
    return 0;
  }

  // Check that maximum mass is large enough,
  double mmax=tab_mvsr->max("gm");
  if (mmax<min_max_mass) {
    scr_out << "Maximum mass too small: " << mmax << " < "
	    << min_max_mass << "." << endl;
    success=false;
    return 0;
  }

  // Check the radius of the maximum mass star
  size_t ix_max=tab_mvsr->lookup("gm",mmax);
  if (tab_mvsr->get("r",ix_max)>1.0e4) {
    scr_out << "TOV convergence problem: " << endl;
    success=false;
    return 0;
  }

  // Check that all stars have masses below the maximum mass
  // of the current M vs R curve
  bool mass_fail=false;
  for(size_t i=0;i<nsources;i++) {
    if (e.mass[i]>mmax) mass_fail=true;
  }
  if (mass_fail==true) {
    scr_out << "Rejected: Mass of object larger than maximum. " << endl;
    success=false;
    return 0;
  }

  // Remove table entries with pressures above the maximum pressure
  double prmax=tab_mvsr->get("pr",
			     tab_mvsr->lookup("gm",tab_mvsr->max("gm")));
  tab_mvsr->delete_rows(((string)"pr>")+dtos(prmax));
  
  if (model_type=="ccs2") {
    // Compute maximum value of c_s^2
    tab_mvsr->add_constant("curr_cs2_max",tab_mvsr->max("cs2"));
  }

  // Make sure that the M vs. R curve generated enough data. This
  // is not typically an issue.
  if (tab_mvsr->get_nlines()<10) {
    scr_out << "M vs. R failed to generate lines." << endl;
    success=false;
    return 0;
  }

  // Compute speed of sound squared
  tab_mvsr->deriv("ed","pr","dpde");
  
  // Output M vs. R curve
  if (debug_star) {
    hdf_file hfds;
    hfds.open("debug_star.o2");
    hdf_output(hfds,*tab_mvsr,"mvsr");
    hfds.close();
    scr_out << "Automatically exiting since 'debug_star' is true." << endl;
    exit(-1);
  }

  // Check causality
  for(size_t i=0;i<tab_mvsr->get_nlines();i++) {
    if ((*tab_mvsr)["dpde"][i]>1.0) {
      scr_out.precision(4);
      scr_out << "Rejected: Acausal."<< endl;
      scr_out << "ed_max="
	      << tab_mvsr->max("ed") << " ed_bad="
	      << (*tab_mvsr)["ed"][i] << " pr_max=" 
	      << tab_mvsr->max("pr") << " pr_bad=" 
	      << (*tab_mvsr)["pr"][i] << endl;
      scr_out.precision(6);
      success=false;
      return 0;
    }
  }

  // Compute the radii for each source
  for(size_t i=0;i<nsources;i++) {
    e.rad[i]=tab_mvsr->interp("gm",e.mass[i],"r");
  }

  return 0;
}

double bamr::hist_get(table3d &t, double ix, double iy, std::string scol) {

  size_t numx=t.get_nx();
  size_t numy=t.get_ny();

  if (numx<2 || numy<2) { 	 
    O2SCL_ERR2_RET("Not enough data in ", 	 
		   "table3d::hist_get().",gsl_einval); 	 
  }

  if (ix<t.get_x_data()[0] || ix>t.get_x_data()[numx-1] || 	 
      iy<t.get_y_data()[0] || iy>t.get_y_data()[numy-1]) { 	 
    O2SCL_ERR2_RET("Out of range in ", 	 
		   "table3d::hist_get().",gsl_einval); 	 
  } 	 
  search_vec<const ovector_base> se(numx,t.get_x_data()); 	 
  search_vec<const ovector_base> se2(numy,t.get_y_data()); 	 

  size_t ival=se.find(ix); 	 
  size_t jval=se2.find(iy); 	 
  return t.get(ival,jval,scol);
}

double bamr::compute_weight(entry &e, model &modref, tov_solve &tsr, 
			     bool &success, uvector &wgts, bool warm_up) {
			     
  // Compute the M vs R curve and return if it failed
  bool compute_star_success;
  compute_star(e,modref,tsr,compute_star_success);
  if (compute_star_success==false) {
    success=false;
    return 0.0;
  }
    
  bool mr_fail=false;
  for(size_t i=0;i<nsources;i++) {
    if (e.mass[i]<m_min || e.mass[i]>m_max ||
	e.rad[i]<r_min || e.rad[i]>r_max) {
      mr_fail=true;
    }
  }

  if (mr_fail==true) {
    scr_out << "Rejected: Mass or radius outside range." << endl;
    if (nsources>0) {
      scr_out.precision(2);
      scr_out.setf(ios::showpos);
      for(size_t i=0;i<nsources;i++) {
	scr_out << e.mass[i] << " ";
      }
      scr_out << endl;
      for(size_t i=0;i<nsources;i++) {
	scr_out << e.rad[i] << " ";
      }
      scr_out << endl;
      scr_out.precision(6);
      scr_out.unsetf(ios::showpos);
    }
    success=false;
    return 0.0;
  }

  success=true;
  double ret=1.0;

  o2_shared_ptr<table_units>::type tab_mvsr=tsr.get_results();
  tab_mvsr->set_interp_type(itp_linear);
  double m_max_current=tab_mvsr->max("gm");

  // -----------------------------------------------
  // Compute the weights for each source

  if (debug_star) scr_out << "Name M R Weight" << endl;

  for(size_t i=0;i<nsources;i++) {
	
    // Double check that current M and R is in the range of
    // the provided input data
    if (e.rad[i]<tlist[i].get_x_data()[0] ||
	e.rad[i]>tlist[i].get_x_data()[tlist[i].get_nx()-1] ||
	e.mass[i]<tlist[i].get_y_data()[0] ||
	e.mass[i]>tlist[i].get_y_data()[tlist[i].get_ny()-1]) {
      wgts[i]=0.0;
    } else {
      // If it is, compute the weight
      wgts[i]=hist_get(tlist[i],e.rad[i],e.mass[i],slice_names[i]);
    }

    // If the weight is lower than the threshold, set it equal
    // to the threshold
    if (wgts[i]<=input_dist_thresh) wgts[i]=input_dist_thresh;

    // Include the weight for this source 
    ret*=wgts[i];

    if (debug_star) {
      scr_out << source_names[i] << " " << e.mass[i] << " " 
	      << e.rad[i] << " " << wgts[i] << endl;
    }
	
    // Go to the next source
  }

  if (debug_star) scr_out << endl;
      
  // -----------------------------------------------
  // Exit if the current maximum mass is too large

  if (m_max_current>exit_mass) {
    scr_out.setf(ios::scientific);
    scr_out << "Exiting because maximum mass larger than 'exit_mass'." 
	    << endl;
    scr_out << "e,ret: " << e << " " << ret << endl;
    exit(-1);
  }

  return ret;//*pow(15.0-tab_mvsr->interp("gm",1.4,"r"),4.0);

  //return 1.0-tab_mvsr->get_constant("curr_cs2_max");
  //return 20.0-r_1;
}

int bamr::read_input(entry &e_current) {
    
  bool debug=true;

  string stmp;
  
  // Open file

  if (debug) {
    scr_out << "Opening input file named: " 
	    << in_file.c_str() << endl;
  }
  ifstream fin(in_file.c_str());
    
  // Read number of sources, and allocate e_current 

  fin >> nsources;
  e_current.allocate(nparams,nsources);

  // Read parameter names and initial guesses

  if (debug) {
    scr_out << "Looking for " << nparams 
	    << " parameter names and initial guesses." << endl;
  }

  for(size_t i=0;i<e_current.np;i++) {
    fin >> stmp;
    fin >> e_current.params[i];
    if (debug) {
      scr_out << i << " " << e_current.params[i] << endl;
    }
  }

  // Read calibrate file

  fin >> calibrate_fname;

  if (debug) {
    scr_out << "Calibrate file: " << calibrate_fname << endl;
  }

  // Read information for each source

  if (nsources>0) {

    fin >> stmp;
    fin >> stmp;
    fin >> stmp;
    fin >> stmp;
    fin >> stmp;
      
    source_names.resize(nsources);
    fnames.resize(nsources);
    slice_names.resize(nsources);
      
    for(size_t i=0;i<nsources;i++) {
      fin >> source_names[i];
      fin >> fnames[i];
      fin >> slice_names[i];
      fin >> e_current.mass[i];
      if (debug) {
	scr_out << i << " ";
	scr_out.width(6);
	scr_out << source_names[i] << " ";
	scr_out.width(30);
	scr_out.setf(ios::left);
	scr_out << fnames[i] << " ";
	scr_out.unsetf(ios::left);
	scr_out.width(6);
	scr_out << slice_names[i] << " " << e_current.mass[i] << endl;
      }
    }

  }

  fin.close();

  return 0;
}

int bamr::set_model(std::vector<std::string> &sv, bool itive_com) {
  if (sv.size()<2) {
    cout << "Model name not given." << endl;
    return gsl_efailed;
  }
  model_type=sv[1];
  if (modp!=0) delete modp;
  if (modp2!=0) delete modp2;
  if (sv[1]=="twop") {
    modp=new two_polytropes;
    modp2=new two_polytropes;
    nparams=8;
    has_esym=true;
    // Cannot output to scr_out since scr_out isn't set until mcmc()
    // is called. 
    // scr_out << "Selected two polytropes." << endl;
  } else if (sv[1]=="altp") {
    modp=new alt_polytropes;
    modp2=new alt_polytropes;
    nparams=8;
    has_esym=true;
    //scr_out << "Selected improved polytropes." << endl;
  } else if (sv[1]=="fixp") {
    modp=new fixed_pressure;
    modp2=new fixed_pressure;
    nparams=8;
    has_esym=true;
    //scr_out << "Selected fixed pressure." << endl;
  } else if (sv[1]=="qstar") {
    modp=new quark_star;
    modp2=new quark_star;
    nparams=4;
    has_esym=false;
    //scr_out << "Selected strange quark star model." << endl;
  } else if (sv[1]=="genq") {
    modp=new generic_quarks;
    modp2=new generic_quarks;
    nparams=9;
    has_esym=true;
    //scr_out << "Selected generic quarks." << endl;
  } else {
    cout << "Model unknown." << endl;
    nparams=0;
    model_type="";
    has_esym=true;
    return gsl_efailed;
  }

  return 0;
}

int bamr::output_best(string fname, entry &e_best, double w_best,
		       o2_shared_ptr<table_units>::type tab_eos,
		       o2_shared_ptr<table_units>::type tab_mvsr,
		       uvector &wgts) {
  
  scr_out << "Best: " << e_best << " " << w_best << endl;

  // "Best" point in parameter space and its associated weight
  string fname2=fname+"_best";
  ofstream fout(fname2.c_str(),ios::app);
  fout.setf(ios::scientific);
  fout.precision(6);
  fout << "Best: " << e_best << " Weights: ";
  if (nsources>0) {
    fout << wgts << " ";
  }
  fout << w_best << endl;
  fout.close();
    
  if (best_detail) {

    // "Best" EOS
    string fname3=fname+"_best_eos";
    hdf_file hf;
    hf.open(fname3);
    hdf_output(hf,*tab_eos,"best_eos");
    hf.close();
    
    // "Best" M vs. R curve
    string fname4=fname+"_best_mvsr";
    hf.open(fname4);
    hdf_output(hf,*tab_mvsr,"best_mvsr");
    hf.close();
  }

  return 0;
}

int bamr::mcmc(std::vector<std::string> &sv, bool itive_com) {

  // User-specified filename prefix
  if (sv.size()<2) {
    cout << "No filename prefix given in bamr::mcmc()." << endl;
    return gsl_efailed;
  }
  string fname=sv[1];
    
  // Get MPI rank, etc.
  MPI_Comm_rank(MPI_COMM_WORLD,&mpi_rank);
  MPI_Comm_size(MPI_COMM_WORLD,&mpi_nprocs);
  mpi_start_time=MPI_Wtime();

  // Update filename with processor rank
  fname+=((string)"_")+itos(mpi_rank);
    
  // Open main output file
  scr_out.open((fname+"_scr").c_str());
  scr_out.setf(ios::scientific);
  
  // Check model
  if (model_type.length()==0 || modp==0 || modp2==0) {
    scr_out << "Model not set." << endl;
    return gsl_efailed;
  }

  // Low-density crust
  if (use_crust) {
    teos.default_low_dens_eos();
  } else {
    teos.no_low_dens_eos();
  }

  bool debug=false;
  if (debug) cout.setf(ios::scientific);
  if (debug) cout.setf(ios::showpos);
    
  // Set RNG seed
  unsigned long int seed=time(0);
  if (user_seed!=0) seed=user_seed;
  seed*=(mpi_rank+1);
  gr.set_seed(seed);
  scr_out << "Using seed " << seed 
	  << " for processor " << mpi_rank+1 << "/" 
	  << mpi_nprocs << "." << endl;
  scr_out.precision(12);
  scr_out << " Start time: " << mpi_start_time << endl;
  scr_out.precision(6);

  // Read input file
  entry e_current;
  read_input(e_current);

  // Set lower and upper bounds
  low.allocate(nparams,nsources);
  high.allocate(nparams,nsources);
  modp->low_limits(low);
  modp->high_limits(high);
  for(size_t i=0;i<nsources;i++) {
    low.mass[i]=m_min;
    high.mass[i]=m_max;
    low.rad[i]=r_min;
    high.rad[i]=r_max;
  }

  // Vector containing weights
  uvector wgts(nsources);

  // Entry objects (Must be after read_input() since nsources is set
  // in that function.)
  entry e_next(nparams,nsources);
  entry e_best(nparams,nsources);

  // Load data
  load_mc();

  // Prepare statistics
  init(low,high);

  // Weights for each entry
  double w_current, w_next, w_best=0.0;

  // Warm-up flag
  bool warm_up=true;

  // Keep track of successful MH moves
  int mh_success_cnt=0;
  
  // Compute initial weight
  bool suc;
  w_current=compute_weight(e_current,*modp,*ts,suc,wgts,warm_up);
  scr_out << "Initial weight: " << w_current << endl;
  if (w_current<=0.0) {
    for(size_t i=0;i<nsources;i++) {
      scr_out << i << " " << wgts[i] << endl;
    }
    scr_out << "Initial weight zero." << endl;
    exit(-1);
  }

  // Initialize radii of e_next to zero
  for(size_t k=0;k<nsources;k++) {
    e_next.rad[k]=0.0;
  }

  // Keep track of total number of different points in the parameter
  // space that are considered (some of them may not result in TOV
  // calls because, for example, the EOS was acausal).
  int iteration=0;

  // Switch between two different Metropolis steps
  bool first_half=true;

  // Main loop
  bool main_done=false;
  size_t block_counter=0;
  while (!main_done) {

    // Make a step, ensure that we're in bounds and that
    // the masses are not too large
    bool bad_step;
    size_t step_count=0;
    do {

      bad_step=false;

      // Step for EOS parameters
      for(size_t k=0;k<e_next.np && bad_step==false;k++) {
	e_next.params[k]=e_current.params[k]+(gr.random()*2.0-1.0)*
	  (high.params[k]-low.params[k])/step_fac;
	if (e_next.params[k]<low.params[k] || 
	    e_next.params[k]>high.params[k]) {
	  //scr_out << "Bad step (EOS limits " << k << ": " << low.params[k]
	  //<< ", " << e_next.params[k] << ", " 
	  //<< high.params[k] << ")." << endl;
	  bad_step=true;
	}
      }

      // Step for masses
      for(size_t k=0;k<nsources && bad_step==false;k++) {
	e_next.mass[k]=e_current.mass[k]+(gr.random()*2.0-1.0)*
	  (high.mass[k]-low.mass[k])/step_fac;
	if (e_next.mass[k]>max_mass) {
	  bad_step=true;
	  //scr_out << "Bad step (Large mass " << k << ")." << endl;
	}
	if (e_next.mass[k]<low.mass[k] || e_next.mass[k]>high.mass[k]) {
	  //scr_out << "Bad step (Mass limit " << k << ")." << endl;
	  bad_step=true;
	} 
      }

      step_count++;
    } while (bad_step && step_count<1e5);

    // Step failed
    if (step_count==1e5) {
      scr_out << "Too many steps in parameter space failed." << endl;
      return gsl_efailed;
    }

    // Output the next point
    if (output_next) {
      scr_out << "Next: " << e_next << endl;
    }
      
    // Compute next weight
    if (first_half) {
      w_next=compute_weight(e_next,*modp2,*ts2,suc,wgts,warm_up);
    } else {
      w_next=compute_weight(e_next,*modp,*ts,suc,wgts,warm_up);
    }
      
    // Test to ensure new point is good
    if (suc==true) {

      // Test radii
      for(size_t i=0;i<nsources;i++) {
	if (e_next.rad[i]>high.rad[i] || 
	    e_next.rad[i]<low.rad[i]) {
	  scr_out << "Rejected: Radius out of range." << endl;
	  suc=false;
	  i=nsources;
	}
      }
	
      // Ensure non-zero weight
      if (w_next==0.0) {
	scr_out << "Rejected: Zero weight." << endl;
	suc=false;
      }
	
    }

    // If the new point is still good, compare with
    // the Metropolis algorithm
    if (suc==true) {

      if (debug) {
	cout << first_half << " Next: " 
	     << e_next.params[0] << " " << w_next << endl;
      }
	
      double r=gr.random();
      if (debug) {
	cout << "Metropolis: " << r << " " << w_next/w_current << endl;
      }

      bool accept=false;
      // Metropolis algorithm, modified during warmup to accept all
      // steps which increase the weight
      if (r<w_next/w_current || (warm_up && w_next>w_current)) accept=true;
      
      if (accept) {

	mh_success_cnt++;
	if (mh_success_cnt>n_warm_up && warm_up==true) {
	  warm_up=false;
	  scr_out << "Setting warm_up to false. Reset start time." << endl;
	  if (true) {
	    max_time-=MPI_Wtime()-mpi_start_time;
	    scr_out << "Resetting max_time to : " << max_time << endl;
	  }
	  mpi_start_time=MPI_Wtime();
	  scr_out.precision(12);
	  scr_out << " Start time: " << mpi_start_time << endl;
	  scr_out.precision(6);
	}
	    
	// Add measurement from new point
	o2_shared_ptr<table_units>::type tab_eos;
	o2_shared_ptr<table_units>::type tab_mvsr;

	if (first_half) {
	  tab_eos=modp2->cns.get_eos_results();
	  tab_mvsr=ts2->get_results();
	} else {
	  tab_eos=modp->cns.get_eos_results();
	  tab_mvsr=ts->get_results();
	}
	tab_eos->set_interp_type(itp_linear);
	tab_mvsr->set_interp_type(itp_linear);

	// Store results from new point
	if (!warm_up) {
	  add_measurement(e_next,tab_eos,tab_mvsr,w_next);
	  if (debug) {
	    cout << first_half << " Adding new: " 
		 << e_next.params[0] << " " << w_next << " "
		 << tab_mvsr->max("gm") << endl;
	  }
	}

	// Output the new point
	scr_out << "MH Acc: " << mh_success_cnt << " " << e_next << " " 
		<< w_next << endl;
	  
	// Keep track of best point
	if (w_next>w_best) {
	  e_best=e_next;
	  w_best=w_next;
	  output_best(fname,e_best,w_best,tab_eos,tab_mvsr,wgts);
	}

	// Prepare for next point
	e_current=e_next;
	w_current=w_next;

	// Flip "first_half" parameter
	first_half=!(first_half);
	if (debug) cout << "Flip: " << first_half << endl;
	  
      } else {
	    
	// Point was rejected

	o2_shared_ptr<table_units>::type tab_eos;
	o2_shared_ptr<table_units>::type tab_mvsr;
	
	if (first_half) {
	  tab_eos=modp->cns.get_eos_results();
	  tab_mvsr=ts->get_results();
	} else {
	  tab_eos=modp2->cns.get_eos_results();
	  tab_mvsr=ts2->get_results();
	}
	tab_eos->set_interp_type(itp_linear);
	tab_mvsr->set_interp_type(itp_linear);

	// Repeat measurement of old point
	if (!warm_up) {
	  add_measurement(e_current,tab_eos,tab_mvsr,w_current);
	  if (debug) {
	    cout << first_half << " Adding old: " 
		 << e_current.params[0] << " " << w_current << " "
		 << tab_mvsr->max("gm") << endl;
	  }
	}

	// Output the old point 
	scr_out << "MH Rej: " << mh_success_cnt << " " << e_current 
		<< " " << w_current << " " << w_next << endl;

	// Keep track of best point
	if (w_next>w_best) {
	  e_best=e_next;
	  w_best=w_next;
	  output_best(fname,e_best,w_best,tab_eos,tab_mvsr,wgts);
	}

      }
	  
      // End of "if (suc==true)"
    }

    bool force_file_update=false;

    if (warm_up==false && iteration%10==9) {
    
      if (max_iters==0) {

	// If necessary, collect a block of histograms
	double elapsed=MPI_Wtime()-mpi_start_time;
	if (elapsed>max_time/((double)20)*((double)(block_counter+1)) ||
	    (elapsed>max_time && block_counter==19)) {
	  force_file_update=true;
	  update_evs();
	  block_counter++;
	  scr_out << "Finished block " << block_counter << " of 20." << endl;
	}
	
	// Check time
	scr_out << "Elapsed time: " << elapsed << " " << max_time << endl;
	if (elapsed>max_time) {
	  main_done=true;
	}

      } else {

	if (iteration+1>max_iters*(((int)block_counter)+1)/20) {
	  force_file_update=true;
	  update_evs();
	  block_counter++;
	  scr_out << "Iteration " << iteration+1 << " of " 
		  << max_iters << ", and finished block " 
		  << block_counter << " of 20." << endl;
	}

	if (iteration+1>max_iters) {
	  scr_out << "Iteration count, " << iteration 
		  << ", exceed maximum number, " << max_iters << "." << endl;
	  main_done=true;
	}
	
      }
     
    }

    // Store a copy of measurements in file
    if (!warm_up && (force_file_update || mh_success_cnt%10==9)) {
      update_files(fname,*modp,e_current);
    }
    
    // Increment iteration counter
    iteration++;

    // End of main loop
  }
   
  scr_out.close();
 
  return 0;
}

int bamr::run(int argc, char *argv[]) {
  
  // ---------------------------------------
  // Specify command-line option object
    
#ifdef BAMR_READLINE
  cli_readline cl;
#else
  cli cl;
#endif
  cl.prompt="bamr> ";
  cl.gnu_intro=false;
    
  // ---------------------------------------
  // Set options
    
  static const int nopt=3;
  comm_option_s options[nopt]={
    {'m',"mcmc","Perform the Markov Chain Monte Carlo simulation.",
     1,1,"<filename prefix>",((string)"This is the main part of ")+
     "the code which performs the simulation. Make sure to set the "+
     "model first using the 'model' command and the input file "+
     "by setting the 'in_file' variable using the 'set' command. "+
     "The one required argument to mcmc is the prefix for the "+
     "output files.",
     new comm_option_mfptr<bamr>(this,&bamr::mcmc),
     cli::comm_option_both},
    {'o',"model","Choose model.",
     1,1,"<model name>",((string)"Choose the EOS parameterization model. ")+
     "Typical values are 'twop', 'impp', 'fixp', and 'genq'.",
     new comm_option_mfptr<bamr>(this,&bamr::set_model),
     cli::comm_option_both},
  };
  cl.set_comm_option_vec(nopt,options);

  // ---------------------------------------
  // Set parameters
    
  cli::parameter_double p_max_time;
  p_max_time.d=&max_time;
  p_max_time.help="Maximum run time in seconds (default 86400 sec or 1 day).";
  cl.par_list.insert(make_pair("max_time",&p_max_time));

  cli::parameter_double p_min_max_mass;
  p_min_max_mass.d=&min_max_mass;
  p_min_max_mass.help=((string)"Minimum maximum mass ")
    +"(in solar masses, default 1.66).";
  cl.par_list.insert(make_pair("min_max_mass",&p_min_max_mass));

  cli::parameter_double p_max_mass;
  p_max_mass.d=&max_mass;
  p_max_mass.help=((string)"Maximum possible mass for any of individual ")+
    "neutron stars in solar masses. (This is not the maximum maximum mass "+
    "of the entire curve). The default is 3.0 solar masses.";
  cl.par_list.insert(make_pair("max_mass",&p_max_mass));

  cli::parameter_double p_step_fac;
  p_step_fac.d=&step_fac;
  p_step_fac.help=((string)"MCMC step factor. The step size for each ")+
    "variable is taken as the difference between the high and low "+
    "limits divided by this factor (default 15.0). This factor can "+
    "be increased if the acceptance rate is too small, but care must "+
    "be taken, e.g. if the conditional probability is multimodal.";
  cl.par_list.insert(make_pair("step_fac",&p_step_fac));

  cli::parameter_double p_exit_mass;
  p_exit_mass.d=&exit_mass;
  p_exit_mass.help=((string)"Upper limit on maximum mass ")+
    "(default 10.0). When the maximum mass is larger than this value, "+
    "the current point in the parameter space is output to 'cout' and "+
    "execution is aborted. This is sometimes useful in debugging the "+
    "initial guess.";
  cl.par_list.insert(make_pair("exit_mass",&p_exit_mass));

  cli::parameter_double p_input_dist_thresh;
  p_input_dist_thresh.d=&input_dist_thresh;
  p_input_dist_thresh.help=((string)"Input distribution threshold. ")+
    "This is the artificial lower limit for the probability of a "+
    "(R,M) pair as reported by the data file. This is sometimes "+
    "useful to gracefully avoid zero probabilities in the input "+
    "data files. The default is 0.";
  cl.par_list.insert(make_pair("input_dist_thresh",&p_input_dist_thresh));

  cli::parameter_int p_warm_up;
  p_warm_up.i=&n_warm_up;
  p_warm_up.help=((string)"Number of warm up iterations (default 500, ")+
    "can be zero).";
  cl.par_list.insert(make_pair("warm_up",&p_warm_up));

  cli::parameter_int p_user_seed;
  p_user_seed.i=&user_seed;
  p_user_seed.help=((string)"Seed for multiplier for random number ")+
    "generator. If zero is given (the default), then mcmc() uses "+
    "time(0) to generate a random seed.";
  cl.par_list.insert(make_pair("user_seed",&p_user_seed));

  cli::parameter_int p_max_iters;
  p_max_iters.i=&max_iters;
  p_max_iters.help=((string)"If non-zero, limit the number of ")+
    "iterations to be less than the specified number (default zero).";
  cl.par_list.insert(make_pair("max_iters",&p_max_iters));

  cli::parameter_bool p_debug_star;
  p_debug_star.b=&debug_star;
  p_debug_star.help=((string)"If true, output stellar properties ")+
    "to file with suffix '_scr' at each point (default false).";
  cl.par_list.insert(make_pair("debug_star",&p_debug_star));

  cli::parameter_bool p_debug_load;
  p_debug_load.b=&debug_load;
  p_debug_load.help=((string)"If true, output info on loaded data ")+
    "(default false).";
  cl.par_list.insert(make_pair("debug_load",&p_debug_load));
  
  cli::parameter_bool p_debug_eos;
  p_debug_eos.b=&debug_eos;
  p_debug_eos.help=((string)"If true, output initial equation of state ")+
    "to file 'eos.dat' and abort (default false).";
  cl.par_list.insert(make_pair("debug_eos",&p_debug_eos));

  cli::parameter_bool p_store_chain;
  p_store_chain.b=&store_chain;
  p_store_chain.help=((string)"If true, output the Markov chain ")+
    " (default false).";
  cl.par_list.insert(make_pair("store_chain",&p_store_chain));

  cli::parameter_bool p_output_next;
  p_output_next.b=&output_next;
  p_output_next.help=((string)"If true, output next point ")+
    "to the '_scr' file before calling TOV solver (default true).";
  cl.par_list.insert(make_pair("output_next",&p_output_next));

  cli::parameter_bool p_baryon_density;
  p_baryon_density.b=&baryon_density;
  p_baryon_density.help=((string)"If true, compute baryon density ")+
    "and store histograms of P vs n_B in files with suffix '_nb' "+
    "(default true).";
  cl.par_list.insert(make_pair("baryon_density",&p_baryon_density));

  cli::parameter_bool p_use_crust;
  p_use_crust.b=&use_crust;
  p_use_crust.help=((string)"If true, use the default crust (default ")+
    "true).";
  cl.par_list.insert(make_pair("use_crust",&p_use_crust));

  cli::parameter_string p_in_file;
  p_in_file.str=&in_file;
  p_in_file.help="Input file name (default \"default.in\").";
  cl.par_list.insert(make_pair("in_file",&p_in_file));
    
  // ---------------------------------------
  // Process command-line arguments and run
    
  cl.run_auto(argc,argv);
    
  return 0;
}

int main(int argc, char *argv[]) {

  // ---------------------------------------
  // Init MPI
  
  MPI_Init(&argc,&argv);

  // ---------------------------------------
  // Main bamr object 
  
  bamr b;
  b.run(argc,argv);
  
  // ---------------------------------------
  // Finalize MPI

  MPI_Finalize();

  return 0;
}
