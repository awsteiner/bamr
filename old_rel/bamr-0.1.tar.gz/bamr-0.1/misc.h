/*
  -------------------------------------------------------------------
  
  Copyright (C) 2012, Andrew W. Steiner
  
  This file is part of Bamr.
  
  Bamr is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 3 of the License, or
  (at your option) any later version.
  
  Bamr is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with Bamr. If not, see <http://www.gnu.org/licenses/>.

  -------------------------------------------------------------------
*/
#ifndef MISC_H
#define MISC_H

#include <iostream>

#include <o2scl/cold_nstar.h>
#include <o2scl/tensor.h>
#include <o2scl/schematic_eos.h>
#include <o2scl/apr_eos.h>
#include <o2scl/skyrme_eos.h>
#include <o2scl/rmf_eos.h>
#include <o2scl/gsl_rnga.h>
#include <o2scl/gsl_mmin_simp.h>
#include <o2scl/hist.h>
#include <o2scl/hist_2d.h>
#include <o2scl/shared_ptr.h>
#include <o2scl/expect_val.h>
#include <o2scl/uniform_grid.h>
#include <o2scl/table3d.h>
#include <o2scl/hdf_file.h>
#include <o2scl/hdf_io.h>
#include <o2scl/poly.h>

#ifndef DOXYGEN
namespace o2scl {
#endif

  /** \brief Define a new histogram object which accesses the
      weights through <tt>operator()</tt>
  */
  class hist_2d_matrix : public hist_2d {

  public:

    // Return a reference to weight at <tt>(i,j)</tt>
    double &operator()(size_t i, size_t j) {
      return get_wgt_i(i,j);
    }

  };
  
  /** \brief A simplified version of cold_nstar 
      
      This simplified version only computes the energy density and 
      pressure, and is used in, e.g., two_polytropes::compute_eos().
  */
  class cold_nstar2 : public cold_nstar {

  public:

    /// Compute the core EOS 
    int calc_eos(double &n1, double &e1, double np_0=0.0);

  };

  /** \brief Single expectation value over a grid defined by a histogram
   */
  class hist_ev_1d {

  public:

    /// Histogram
    hist h;
    /// Count of measurements
    size_t count;
    /// Expectation value object
    vector_ev ev;

    /// Record hist in ev object
    void update() {
      if (false) {
	if (count>0) {
	  for(size_t i=0;i<h.size();i++) {
	    h[i]/=((double)count);
	  }
	}
      }
      ev.add(h);
      h.clear_wgts();
      count=0;
      return;
    }

  };

  /** \brief Two-dimensional expectation value over a grid 
      defined by a two-dimensional histogram
   */
  class hist_ev_2d {

  public:

    /// Histogram
    hist_2d_matrix h;
    /// Count of measurements
    size_t count;
    /// Expectation value object
    matrix_ev ev;

    /// Record hist in ev object
    void update() {
      if (false) {
	if (count>0) {
	  for(size_t i=0;i<h.size_x();i++) {
	    for(size_t j=0;j<h.size_y();j++) {
	      h.get_wgt_i(i,j)/=((double)count);
	    }
	  }
	}
      }
      ev.add(h);
      h.clear_wgts();
      count=0;
      return;
    }

  };

  /** \brief Set of one-dimensional histograms over a grid in y
   */
  class hist_set_ev_y {

  public:

    /// Histogram
    hist_2d_matrix h;
    /// Count of measurements for each histogram in the set
    uvector_size_t count;
    /// Expectation value object
    matrix_ev ev;

    /// Record hist in ev object
    void update() {
      if (false) {
	double cmax=((double)count.max());
	if (cmax==0.0) cmax=1.0;
	for(size_t j=0;j<h.size_y();j++) {
	  if (count[j]>0) {
	    for(size_t i=0;i<h.size_x();i++) {
	      //h.get_wgt_i(i,j)/=cmax;
	      h.get_wgt_i(i,j)/=((double)count[j]);
	    }
	  }
	}
      }
      ev.add(h);
      h.clear_wgts();
      count.set_all(0);
      return;
    }

  };

  /** \brief Set of one-dimensional histograms over a grid in x
   */
  class hist_set_ev_x {

  public:

    /// Histogram
    hist_2d_matrix h;
    /// Count of measurements for each histogram in the set
    uvector_size_t count;
    /// Expectation value object
    matrix_ev ev;

    /// Record hist in ev object
    void update() {
      if (false) {
	double cmax=((double)count.max());
	if (cmax==0.0) cmax=1.0;
	for(size_t i=0;i<h.size_x();i++) {
	  if (count[i]>0) {
	    for(size_t j=0;j<h.size_y();j++) {
	      //h.get_wgt_i(i,j)/=cmax;
	      h.get_wgt_i(i,j)/=((double)count[i]);
	    }
	  }
	}
      }
      ev.add(h);
      h.clear_wgts();
      count.set_all(0);
      return;
    }

  };

#ifndef DOXYGEN
}
#endif

#endif
