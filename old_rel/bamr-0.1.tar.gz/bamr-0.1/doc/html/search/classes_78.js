var searchData=
[
  ['xmatrix',['xmatrix',['http://o2scl.sourceforge.net/o2scl/html/classxmatrix.html',1,'']]]
];
