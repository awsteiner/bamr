var searchData=
[
  ['hfunc_5ft',['hfunc_t',['http://o2scl.sourceforge.net/o2scl/html/classool__mmin__pgrad.html#a1827e190f4fee21095f81b46484a6e6a',1,'ool_mmin_pgrad::hfunc_t()'],['http://o2scl.sourceforge.net/o2scl/html/classool__mmin__spg.html#a2650536980cac195d3b59ba86eb3fa84',1,'ool_mmin_spg::hfunc_t()']]]
];
