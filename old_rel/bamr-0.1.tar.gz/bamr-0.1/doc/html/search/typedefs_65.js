var searchData=
[
  ['extrap_5ftable',['extrap_table',['http://o2scl.sourceforge.net/o2scl/html/classgsl__inte__singular.html#a1df37c30d0a60808cb18feebd1417768',1,'gsl_inte_singular']]]
];
