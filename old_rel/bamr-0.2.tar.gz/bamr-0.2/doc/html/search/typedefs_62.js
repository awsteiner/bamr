var searchData=
[
  ['base_5ffit_5ft',['base_fit_t',['http://o2scl.sourceforge.net/o2scl/html/classfit__fix__pars.html#a78b7c2b9e8389988377534397e150257',1,'fit_fix_pars']]],
  ['base_5fmmin_5ft',['base_mmin_t',['http://o2scl.sourceforge.net/o2scl/html/classmulti__min__fix.html#a2b2ad44c6b8d42168b4c8ccf64c03b64',1,'multi_min_fix']]]
];
