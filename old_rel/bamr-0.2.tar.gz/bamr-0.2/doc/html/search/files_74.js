var searchData=
[
  ['tensor_2eh',['tensor.h',['http://o2scl.sourceforge.net/o2scl/html/tensor_8h.html',1,'']]],
  ['tridiag_5fbase_2eh',['tridiag_base.h',['http://o2scl.sourceforge.net/o2scl/html/tridiag__base_8h.html',1,'']]]
];
